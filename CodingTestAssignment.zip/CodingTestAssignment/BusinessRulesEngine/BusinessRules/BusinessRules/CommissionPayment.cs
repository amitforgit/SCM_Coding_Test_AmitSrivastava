﻿using BusinessRulesEngine.Models;
using System;

namespace BusinessRulesEngine.BusinessRules
{
    /// <summary>
    /// CommissionPayment
    /// </summary>
    public class CommissionPayment : ICommissionPayment
    {
        /// <summary>
        /// GenerateCommissionPayment
        /// </summary>
        /// <param name="PaymentMethod"></param>
        // Generate Commission Payment Class
        public void GenerateCommissionPayment(PaymentModel PaymentMethod)
        {
            // To implement the logic
            throw new NotImplementedException();
        }
    }
}
