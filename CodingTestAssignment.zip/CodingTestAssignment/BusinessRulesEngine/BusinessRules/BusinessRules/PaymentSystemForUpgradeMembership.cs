﻿using BusinessRulesEngine.Models;
using System;

namespace BusinessRulesEngine.BusinessRules
{
    /// <summary>
    /// PaymentSystemForUpgradeMembership
    /// </summary>
    
    public class PaymentSystemForUpgradeMembership : IPaymentSystem
    {
        /// <summary>
        /// PaymentSystemForUpgradeMembership Constructor
        /// </summary>
        public PaymentSystemForUpgradeMembership()
        {

        }

        // Implement the Package Slip Generation for UpgradeMembership
        public int GenerateSlipForShipping(PaymentModel PaymentMethod)
        {
            // To implement the logic
            throw new NotImplementedException();
        }
    }
}
