﻿using BusinessRulesEngine.Models;

namespace BusinessRulesEngine.BusinessRules
{
    /// <summary>
    /// IAddFreeToPackingSlip
    /// </summary>
    public interface IAddFreeToPackingSlip
    {
        /// <summary>
        /// AddFreeSubscription
        /// </summary>
        /// <param name="PaymentMethod"></param>
        // Add Free Subscription
        void AddFreeSubscription(PaymentModel PaymentMethod);
    }
}
