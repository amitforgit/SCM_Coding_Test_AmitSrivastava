﻿using BusinessRulesEngine.Models;

namespace BusinessRulesEngine.BusinessRules
{
    /// <summary>
    /// ICommissionPayment
    /// </summary>
    public interface ICommissionPayment
    {
        /// <summary>
        /// GenerateCommissionPayment
        /// </summary>
        /// <param name="PaymentMethod"></param>
        // Generate Commission Payment
        void GenerateCommissionPayment(PaymentModel PaymentMethod);
    }
}
