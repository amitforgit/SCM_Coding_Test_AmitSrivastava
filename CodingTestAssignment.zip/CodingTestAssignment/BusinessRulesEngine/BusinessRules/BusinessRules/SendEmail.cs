﻿using BusinessRulesEngine.Models;
using System;

namespace BusinessRulesEngine.BusinessRules
{
    /// <summary>
    /// SendEmail
    /// </summary>
    public class SendEmail : ISendEmail
    {
        /// <summary>
        /// SendEmail
        /// </summary>
        /// <param name="emailModel"></param>
        // Send Email Trigger
        public void SendEmailAndUpdateForUpgrade(EmailModel emailModel)
        {
            // To implement the logic
            // Using SendGrid to trigger/send email.
            throw new NotImplementedException();
        }
    }
}
