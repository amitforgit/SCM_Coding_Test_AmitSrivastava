﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace BusinessRulesEngine.Models
{
    /// <summary>
    /// EmailModel
    /// </summary>
    // Email Model
    public class EmailModel
    {
        /// <summary>
        /// Email
        /// </summary>
        [Required(ErrorMessage = "{0} is required")]
        public string Email { get; set; }

        /// <summary>
        /// Description
        /// </summary>
        [Required(ErrorMessage = "{0} is required")]
        public string Description { get; set; }

        /// <summary>
        /// BodyText
        /// </summary>
        [Required(ErrorMessage = "{0} is required")]
        public string BodyText { get; set; }

        /// <summary>
        /// OwnerId from PaymentModel
        /// </summary>
        public string OwnerId { get; set; }
    }
}
