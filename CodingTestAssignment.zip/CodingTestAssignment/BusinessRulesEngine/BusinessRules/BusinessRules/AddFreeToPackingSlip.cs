﻿using BusinessRulesEngine.Models;
using System;

namespace BusinessRulesEngine.BusinessRules
{
    public class AddFreeToPackingSlip : IAddFreeToPackingSlip
    {
        /// <summary>
        /// AddFreeSubscription
        /// </summary>
        /// <param name="PaymentMethod"></param>        
        public void AddFreeSubscription(PaymentModel PaymentMethod)
        {
            // To implement the logic
            throw new NotImplementedException();
        }
    }
}
