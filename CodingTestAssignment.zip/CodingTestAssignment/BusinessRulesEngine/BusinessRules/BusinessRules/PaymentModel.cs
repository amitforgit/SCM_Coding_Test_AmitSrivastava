﻿namespace BusinessRulesEngine.Models
{
    /// <summary>
    /// PaymentModel
    /// </summary>
    public class PaymentModel
    {
        // Define Properties associated
        /// <summary>
        /// ProductId
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// ProductDetails
        /// </summary>
        public string ProductDetails { get; set; }

        /// <summary>
        /// ProductOwner
        /// </summary>

        public string ProductOwner { get; set; }

        /// <summary>
        /// OwnerEmail
        /// </summary>
        public string OwnerId { get; set; }

    }
}
