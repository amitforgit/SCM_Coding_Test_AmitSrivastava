﻿using BusinessRulesEngine.Models;

namespace BusinessRulesEngine.BusinessRules
{
    /// <summary>
    /// ISendEmail
    /// </summary>
    public interface ISendEmail
    {
        /// <summary>
        /// SendEmailAndUpdateForUpgrade
        /// </summary>
        /// <param name="emailModel"></param>
        // Send Email Interface
        void SendEmailAndUpdateForUpgrade(EmailModel emailModel);
    }
}
