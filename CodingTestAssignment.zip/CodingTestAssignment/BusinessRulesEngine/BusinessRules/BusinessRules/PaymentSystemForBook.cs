﻿using BusinessRulesEngine.Models;
using System;

namespace BusinessRulesEngine.BusinessRules
{
    /// <summary>
    /// PaymentSystemForBook
    /// </summary>
    public class PaymentSystemForBook : IPaymentSystem
    {
        /// <summary>
        /// PaymentSystemForBook Constructor
        /// </summary>
        public PaymentSystemForBook()
        {

        }
        // Implement the Package Slip Generation for Book   
        public int GenerateSlipForShipping(PaymentModel PaymentMethod)
        {
            // To implement the logic
            throw new NotImplementedException();
        }
    }
}
