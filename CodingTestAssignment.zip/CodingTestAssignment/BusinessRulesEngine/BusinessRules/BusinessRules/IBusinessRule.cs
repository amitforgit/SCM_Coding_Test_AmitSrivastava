﻿using BusinessRulesEngine.Models;

namespace BusinessRulesEngine.BusinessRules
{
    /// <summary>
    /// IPaymentSystem
    /// </summary>
    public interface IPaymentSystem
    {
        /// <summary>
        /// GenerateSlipForShipping
        /// </summary>
        /// <param name="PaymentMethod"></param>
        /// <returns></returns>
        int GenerateSlipForShipping(PaymentModel PaymentMethod);
    }
}
