﻿using BusinessRulesEngine.Models;
using System;

namespace BusinessRulesEngine.BusinessRules
{
    /// <summary>
    /// PaymentSystemForPhysicalProduct
    /// </summary>
    public class PaymentSystemForPhysicalProduct : IPaymentSystem
    {
        /// <summary>
        /// PaymentSystemForPhysicalProduct Constructor
        /// </summary>
        public PaymentSystemForPhysicalProduct()
        {
        }
       
        // Implement the Package Slip Generation for Physical Product
        public int GenerateSlipForShipping(PaymentModel PaymentMethod)
        {
            // To implement the logic
            throw new NotImplementedException();
        }
    }
}
