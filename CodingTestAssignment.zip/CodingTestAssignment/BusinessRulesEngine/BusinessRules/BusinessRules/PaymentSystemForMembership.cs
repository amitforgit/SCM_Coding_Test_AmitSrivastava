﻿using BusinessRulesEngine.Models;
using System;

namespace BusinessRulesEngine.BusinessRules
{
    /// <summary>
    /// PaymentSystemForMembership
    /// </summary>
    public class PaymentSystemForMembership : IPaymentSystem
    {
        /// <summary>
        /// PaymentSystemForMembership Constructor
        /// </summary>
        public PaymentSystemForMembership()
        {

        }
        
        /// <summary>
        /// GenerateSlipForShipping
        /// </summary>
        /// <param name="PaymentMethod"></param>
        /// <returns></returns>

        // Implement the Package Slip Generation for Membership
        public int GenerateSlipForShipping(PaymentModel PaymentMethod)
        {
            // To implement the logic
            throw new NotImplementedException();
        }
    }
}
