﻿using System;

namespace BusinessRules
{
    /// <summary>
    /// BusinessModel
    /// </summary>
    // Business Model to keep data
    public class BusinessModel
    {

    }
}
