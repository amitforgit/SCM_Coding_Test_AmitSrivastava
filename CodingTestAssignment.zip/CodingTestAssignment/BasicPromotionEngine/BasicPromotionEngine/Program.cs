﻿using BasicPromotionEngine.Helper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace BasicPromotionEngine
{
    /// <summary>
    /// Program Class
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Main
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {
            // Initial Sku defined
            var listSku = InitialSetup.InitializeSku();
            Dictionary<string, int> skuUnit = new Dictionary<string, int>();

            Console.WriteLine("Enter the scenario with comma separated value eg: 3A,2B,1C");
            Console.WriteLine("Make sure to enter combination values with % specifiier eg: 1C%1D");

            string scenario = Console.ReadLine();

            // Get all the values from the config file
            GetConfigurationDetails(skuUnit, scenario);

            // Get the price from the CalculatePromotion 
            double totalPrice = PromotionEngine.CalculatePromotion(skuUnit, listSku);
            Console.WriteLine("Price for the Listed Items are:" + totalPrice);

            Console.ReadLine();
        }

        /// <summary>
        /// GetConfigurationDetails
        /// </summary>
        /// <param name="skuUnit"></param>
        /// <param name="scenario"></param>

        private static void GetConfigurationDetails(Dictionary<string, int> skuUnit, string scenario)
        {
            foreach (string value in scenario.Split(","))
            {
                if (!value.Contains("%"))
                {
                    skuUnit.Add(value.Substring(value.Length - 1), Convert.ToInt32(value.Substring(0, value.Length - 1)));
                }
                else
                {
                    // In case of value contains % then set it 0 and get it from calculation
                    skuUnit.Add(value, 0);
                }
            }
        }
    }
}

